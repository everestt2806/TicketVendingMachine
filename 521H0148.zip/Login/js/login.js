var flag = 0;
function submitForm() {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  var result = document.getElementById('result');

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var message = this.responseText;
      if (message == 'LOGIN SUCCESSFUL!') {
        alert(message);
        setTimeout(function(){
          window.location.href = "url";
        }, 500);
      }
      else {
        result.innerHTML = message;
        return false;
      }
      flag = 1;
      return true;
    }
  };
  xhttp.open("POST", "http://localhost/Web/login.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("username=" + username + "&password=" + password);
}

function checkAct() {
  if (flag == 1) {
    
    return true;
  }
  return false;
}
function HideError() {
  var error = document.getElementById('result');
  error.innerHTML = "";
}

