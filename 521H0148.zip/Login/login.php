<?php
header("Access-Control-Allow-Origin: *");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  if ($username == 'Test' && $password == 'Test.1234') {
    echo 'Login successed!';
  } else {
    echo 'Your username or password is incorrect!';
  }
}
?>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
  $username = $_POST['username'];
  
}

?>
